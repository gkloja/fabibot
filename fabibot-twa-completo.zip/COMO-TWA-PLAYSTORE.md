# Fabi Bot → App Android (TWA) na Play Store

## O que já foi preparado neste pacote

- `site.webmanifest` — melhorado para TWA/PWA
- `sw.js` — Service Worker básico (cache offline da home e ícones)
- `assetlinks.json` — template do Digital Asset Links (você completa o SHA-256)
- Instruções abaixo para gerar o app com Bubblewrap

---

## 1. Colocar os arquivos no site

Na raiz do repositório (junto com `index.html`):

1. Substitua/atualize `site.webmanifest`
2. Adicione `sw.js`
3. Crie a pasta `.well-known` e dentro dela coloque `assetlinks.json`  
   Caminho final: `https://www.fabibot.com.br/.well-known/assetlinks.json`

No `index.html` (e páginas principais), registre o Service Worker (se ainda não tiver). Coloque antes do `</body>`:

```html
<script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    });
  }
</script>
```

Faça commit + push e confirme no ar:
- https://www.fabibot.com.br/site.webmanifest
- https://www.fabibot.com.br/sw.js
- (depois) https://www.fabibot.com.br/.well-known/assetlinks.json

---

## 2. Conta Google Play

1. Acesse: https://play.google.com/console
2. Pague a taxa única de **US$ 25** (conta de desenvolvedor)
3. Crie um app novo (nome: Fabi Bot, etc.)

---

## 3. Gerar o app com Bubblewrap (no seu computador)

Precisa ter instalado:
- Node.js (18+)
- JDK 17
- Android SDK command-line tools (ou Android Studio)

```bash
# Instalar Bubblewrap
npm install -g @bubblewrap/cli

# Criar pasta do projeto Android
mkdir fabibot-twa && cd fabibot-twa

# Inicializar a partir do manifest do site
bubblewrap init --manifest=https://www.fabibot.com.br/site.webmanifest
```

O assistente vai perguntar:

| Campo | Sugestão |
|-------|----------|
| Domain | www.fabibot.com.br |
| URL path | / |
| Package name | br.com.fabibot.app |
| App name | Fabi Bot |
| Launcher name | FabiBot |
| Theme color | #16a34a |
| Background color | #0A0A0A |

Na geração da **keystore**, anote a senha e o alias.  
No final do `init`, o Bubblewrap mostra o **SHA-256** da chave. **Copie esse valor.**

---

## 4. Completar o assetlinks.json

1. Abra o `assetlinks.json` do site
2. Substitua `COLE_AQUI_O_SHA256_DEPOIS_DO_BUBBLEWRAP` pelo SHA-256 que o Bubblewrap mostrou (formato com `:` ou sem, o Bubblewrap indica)
3. Confirme o `package_name` igual ao que você usou (`br.com.fabibot.app`)
4. Faça deploy de novo

Teste:  
https://www.fabibot.com.br/.well-known/assetlinks.json  
deve abrir o JSON (Content-Type: application/json, sem redirect).

---

## 5. Build do App Bundle

```bash
cd fabibot-twa
bubblewrap build
```

Será gerado algo como:
- `app-release-bundle.aab` ← **esse você envia na Play Console**
- `app-release-signed.apk` ← para testar no celular

---

## 6. Enviar na Play Console

1. Play Console → seu app → Produção (ou teste interno primeiro)
2. Criar nova versão → upload do `.aab`
3. Preencher ficha da loja (descrição, prints, ícone 512, categoria, etc.)
4. Política de privacidade: use `https://www.fabibot.com.br/privacidade`
5. Enviar para revisão

---

## 7. Checklist rápido

- [ ] site.webmanifest no ar
- [ ] sw.js registrado no index
- [ ] Conta Play Developer ativa
- [ ] bubblewrap init + build
- [ ] SHA-256 no assetlinks.json publicado
- [ ] .aab enviado na Play Console
- [ ] Ficha da loja preenchida

---

## Dicas

- Comece com **teste interno** (só você e emails) antes de produção.
- O app na Play Store **abre o site** em tela cheia (Chrome). Qualquer atualização do site já vale no app.
- Se a barra de URL aparecer no app, o `assetlinks.json` está errado ou não propagou.

Qualquer dúvida nos comandos do Bubblewrap, manda o erro que eu te ajudo.
